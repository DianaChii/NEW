/**
 * @typedef {Object} player
 * @property {string} color - Цвет игрока
 */

/**
 * @typedef {Object} hex
 * @property {string} color - Цвет гексагона
 * @property {number} playerIdx - Номер игрока
 */

/**
 * @typedef {Object} hexLine
 * @property {number} start - Начало линии
 * @property {number} end - Конец линии
 * @property {string} axis - Ось линии
 * @property {number} offset - Смещение по противоположной оси
 */

/**
 * @typedef {Object} position
 * @property {number} x - Положение по оси X
 * @property {number} y - Положение по оси Y
 */


const body = document.getElementsByTagName('body')[0];

/** Элемент старницы - холст */
const canvas = document.getElementById('hexmap');
/** 
 * Содрежание элемента холста<br>
 * Относится к объекту {@link canvas}<br>
 */
const ctx = canvas.getContext('2d'); 

const main_menu = document.getElementById('main-menu');
// const play_button = document.getElementById('play-button');
const play_buttons = [
    document.getElementById('play-button0'),
    document.getElementById('play-button1'),
];


const player_info_menu = document.getElementById('game-menu');

const player_colors = [
    document.getElementById('player-color0'),
    document.getElementById('player-color1'),
];
const player_status = [
    document.getElementById('status-player0'),
    document.getElementById('status-player1'),
];


const game_over_menu = document.getElementById('game-over-menu');
const game_over_text = document.getElementById('game-over-text');

/** 
 * Статус игры
 * @type {boolean}
 */
let isGameStarted = false;
/** 
 * Статус игры
 * @type {boolean}
 */
let isGameBot = false;

/**
 * Ширина игрового поля - количетсво гексагонов в ширину
 * @type {number}
 */
const boardWidth = 47;

/**
 * Высота игрового поля - количетсво гексагонов в высоту
 * @type {number}
 */
const boardHeight = 21;
const canvasScale = 16;
const scaleFactor = 100;

/**
 * Размеры экрана холста 
 * @type {Object}
 * @property {function} x - Возращает ширину экрана холста
 * @property {function} y - Возращает высоту экрана холста
 */
let windowScale = { 
    x: () => { return (2 * boardWidth / scaleFactor) * window.innerWidth },
    y: () => { return (1.75 * boardHeight / scaleFactor) * window.innerWidth },
};

/**
 * Высота гексагона
 * @type {number}
 */
let hexHeight;

/**
 * Радиус гексагона
 * @type {number}
 */
let hexRadius;

/**
 * Высота гексангона<br>
 * От минимальной точки к максимальной<br>
 * @type {number}
 */
let hexRectangleHeight;

/**
 * Ширина гексагона<br>
 * От минимальной точки к максимальной<br>
 * @type {number}
 */
let hexRectangleWidth;

/**
 * Размер боковой cтороны гексагона
 * @type {number}
 */
let hexSideLength = canvasScale * getScaling();

/**
 * Угол гексагона<br>
 * 30 градусов в радинанах<br>
 * @type {number}
 */
const hexagonAngle = 0.523598776;

/**
 * Размер шрифта
 * @type {number}
 */
let fontScale = canvasScale * getScaling();

const lineWidth = 0.125;
ctx.lineWidth = (lineWidth * canvasScale * getScaling()); 
ctx.strokeStyle = "black";

/**
 * Цвет выделения
 * @type {number}
 */
const highlightFill = "rgba(255,255,255,0.75)";
ctx.fillStyle = highlightFill;

/**
 * Позиция курсора на холсте
 * @type {position}
*/
let mousePosition = { x: 0, y: 0 };
/** 
 * Выделенный гексагон с помощью курсора
 * @type {position}
 */
let hexSelected = { x: 0, y: 0 };
/**
 * Предыдущий выделенный гексагон
 * @type {position}
 */
let previousHexSelected = { x: 0, y: 0 };


/**
 * Список доступных цветов
 * @type {Array<string>}
 */
const colorsList = [ "white", "red", "green", "lightgreen", "blue", "skyblue", "magenta", "yellow", "orange" ];
/**
 * Список тёмных цветов
 * @type {Array<string>}
 */
const colorsDarkList = [ "blue", "green" ]

/**
 * Список игроков
 * @type {Array<player>}
 */
let playersList = [{}, {}];

/**
 * Номер активного игрока
 * @type {number}
 */
let activePlayer = 0;


/**
 * Список гексагонов
 * @type {Array<Array<hex>>}
 */
let hexList = [];

/**
 * Список гексагонных границ
 * @type {Array<hexLine>}
 */
let hexLineBorder = [
    { start: 0, end: 5, axis: "y", offset: 10 },
    { start: 0, end: 5, axis: "y", offset: (boardWidth - 10) },
    { start: (boardHeight - 5), end: boardHeight, axis: "y", offset: 10 },
    { start: (boardHeight - 5), end: boardHeight, axis: "y", offset: (boardWidth - 10) },

    { start: 10, end: 18, axis: "x", offset: 5 },
    { start: 10, end: 18, axis: "x", offset: (boardHeight - 6) },
    { start: (boardWidth - 10), end: (boardWidth - 18), axis: "x", offset: 5 },
    { start: (boardWidth - 10), end: (boardWidth - 18), axis: "x", offset: (boardHeight - 6) },
];


/* Util-функции */

/**
 * Размер относительно длины ширины экрана
 * @returns {number} Размер экрана
 */
function getScaling() {
    return windowScale.x() / 1320;
}

/** Изменение размера холста страницы */
function screenResize() {
    canvas.width = windowScale.x();
    canvas.height = windowScale.y();
}

/** Изменение метода заполнения заднего фона, в зависимости от соотоношения сторон экрана */
function backgroundResize() {
    if (window.innerWidth/1.8 >= window.innerHeight) {
        body.style['background-size'] = "100% auto";
    } else {
        body.style['background-size'] = "auto 100%";
    }
}

/** Обновление параметров размеров гексагона */
function updateHexSize() {
    hexRadius = Math.cos(hexagonAngle) * hexSideLength;
    hexHeight = Math.sin(hexagonAngle) * hexSideLength;
    
    hexRectangleWidth = 2 * hexRadius;
    hexRectangleHeight = hexSideLength + 2 * hexHeight;
}

/**
 * Получение случайного номера из списка цветов<br>
 * Используемые элементы:<br>
 * [Переменная списка] {@link colorsList}<br>
 * @returns {number} Номер цвета
 */
function getRandomColorIndex() {
    return Math.min(Math.floor(Math.random() * colorsList.length), (colorsList.length - 1));
}


/* Рендер функции */

/**
 * Обновление размеров экрана и элементов
 * Используемые элементы:<br>
 * [Функция отрисовки] {@link screenResize}<br>
 * [Функция отрисовки] {@link backgroundResize}<br>
 * [Функция отрисовки] {@link updateHexSize}<br>
 * [Функция отрисовки] {@link updateCanvas}<br>
 */
function updateScreenSizing() {
    screenResize();
    backgroundResize();

    ctx.lineWidth = (lineWidth * canvasScale * getScaling()); 
    hexSideLength = canvasScale * getScaling();
    fontScale = canvasScale * getScaling();
    updateHexSize();

    if (!isGameStarted) { return }; 
    updateCanvas();
}

/**
 * Отрисовка объектов на холсте<br>
 * Используемые элементы:<br>
 * [Функция отрисовки] {@link drawFilledHex}<br>
 * [Функция отрисовки] {@link drawBoard}<br>
 */
function updateCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawFilledHex();
    drawBoard();
}

/**
 * Отрисовка сетки гексагонов на холсте<br>
 * Используемые элементы:<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Функция отрисовки] {@link drawHexagon}<br>
 */
function drawBoard() {
    for(let x = 0; x < boardWidth; ++x) { 
        for(let y = 0; y < boardHeight; ++y) { 
            drawHexagon( 
                x * hexRectangleWidth + ((y % 2) * hexRadius),  
                y * (hexSideLength + hexHeight),  
                false 
            ); 
        } 
    }
} 

/**
 * Отрисовка цветов гексагонов на холсте<br>
 * Используемые элементы:<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Переменная списка] {@link colorsList}<br>
 * [Переменная списка] {@link playersList}<br>
 * [Функция отрисовки] {@link drawHexagon}<br>
 */
function drawFilledHex() {
    for (let x = 0; x < boardWidth; x++) {
        for (let y = 0; y < boardHeight; y++) {
            let hex = hexList[x][y]
            let color = hex.color || playersList[hex.playerIdx].color;
            drawHexagon(  
                x * hexRectangleWidth + ((y % 2) * hexRadius),  
                y * (hexSideLength + hexHeight),  
                true,
                color,
                hex.hasOwnProperty("playerIdx") ? String(hex.playerIdx+1) : ''
            );
        }
    }
}

/**
 * Отрисовка гексагона на холсте<br>
 * Используемые элементы:<br>
 * [Объект] {@link ctx}<br>
 * @param {number} x - Положение по оси X
 * @param {number} y - Положение по оси Y
 * @param {boolean} [fill] - Выполнение заливки цветом
 * @param {string} [color] - Цвет заливки
 * @param {string} [displayText] - Отображаемый текст
 */
function drawHexagon(x, y, fill = false, color = "white", displayText = '') {   
    x += ctx.lineWidth; y += ctx.lineWidth;

    ctx.beginPath(); 
    ctx.moveTo(x + hexRadius, y); 
    ctx.lineTo(x + hexRectangleWidth, y + hexHeight); 
    ctx.lineTo(x + hexRectangleWidth, y + hexHeight + hexSideLength); 
    ctx.lineTo(x + hexRadius, y + hexRectangleHeight); 
    ctx.lineTo(x, y + hexSideLength + hexHeight); 
    ctx.lineTo(x, y + hexHeight); 
    ctx.closePath(); 

    if(fill) { 
        ctx.fillStyle = color;
        ctx.fill();

        if (displayText) {
            ctx.fillStyle = "black";
            if (colorsDarkList.includes(color, 0)) { ctx.fillStyle = "white"; };

            ctx.font=`${fontScale}px Yanone Kaffeesatz`;
            ctx.fillText(displayText, x + hexRectangleWidth/2 - fontScale/4.5, y + hexRectangleHeight/2 + fontScale/3.5);
        }
    } else { 
        ctx.stroke(); 
    } 
}

/** Обновление цвета игроков на элементах */
function updatePlayerDisplayColor() {
    player_colors[0].style['background-color'] = playersList[0].color;
    player_colors[1].style['background-color'] = playersList[1].color;
}

/** Обновление статуса активного игрока на элементах */
function updatePlayerHighlight() {
    player_status[(    activePlayer)].classList.add("action-player");
    player_status[(1 - activePlayer)].classList.remove("action-player");
}

/** Закрытие главного меню, и отображение игровых элементов */
function gameStart() {
    main_menu.style['display'] = "none";
    main_menu.style['visibility'] = "hidden";

    player_info_menu.style['display'] = "inherit";
    player_info_menu.style['visibility'] = "visible";

    updatePlayerDisplayColor();
    updatePlayerHighlight();

    updateCanvas();
    isGameStarted = true;
}

/** Вывовод окна окончания игры */
function gameOver() {
    let playersScore = [0, 0];

    for (let x = 0; x < boardWidth; x++) {
        for (let y = 0; y < boardHeight; y++) {
            let infoHex = hexList[x][y];
            if (infoHex.hasOwnProperty("playerIdx")) {
                playersScore[infoHex.playerIdx] += 1;
            }
        }
    }

    let textOutput = "Ничья";
    if (playersScore[0] > playersScore[1]) {
        textOutput = "Победил Игрок 1";
    } else if (playersScore[0] < playersScore[1]) {
        textOutput = "Победил Игрок 2";
    }
    game_over_text.innerHTML = textOutput;

    game_over_menu.style['display'] = "flex";
    game_over_menu.style['visibility'] = "visible";

    isGameStarted = false;
}


/* Игровые функции */

/**
 * Заполнения поля гексагонами случайного цвета<br>
 * Используемые элементы:<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Переменная списка] {@link colorsList}<br>
 * [Переменная списка] {@link hexList}<br>
 */
function fillRandomHexBoard() {
    for (let x = 0; x < boardWidth; x++) {
        hexList[x] = [];
        for (let y = 0; y < boardHeight; y++) {
            let colorIdx = getRandomColorIndex();
            hexList[x][y] = {color: colorsList[colorIdx]};
        }
    }
}

/**
 * Заполнение поля границами из списка<br>
 * Используемые элементы:<br>
 * [Переменная списка] {@link hexList}<br>
 * @param {Array<hexLine>} borderList - Список линий гексагонов
 */
function createHexLineBorder(borderList) {
    for (let hexLine of borderList) {
        let min = Math.min(hexLine.start, hexLine.end),
            max = Math.max(hexLine.start, hexLine.end);
    
        for (let i = min; i < max; i++) {
            let offset = hexLine.offset;
            if (hexLine.axis == "x") {
                hexList[i][offset].color = "black";
            } else if (hexLine.axis == "y") {
                hexList[offset][i].color = "black";
            }
        }
    }
}

/**
 * Задание цвета для гексагона текущим игроком<br>
 * Используемые элементы:<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Переменная списка] {@link hexList}<br>
 * [Переменная списка] {@link playersList}<br>
 * [Функция] {@link closestHexParent}<br>
 * [Функция отрисовки] {@link updateCanvas}<br>
 * [Функция] {@link updatePlayerDisplayColor}<br>
 * [Функция] {@link switchPlayer}<br>
 * @param {Object<position>} position - Позиция закрашиваемого гексагона
 */
function setPlayerColorHex(position) {
    if(position.x < 0 || position.x > (boardWidth -  1)) { return };
    if(position.y < 0 || position.y > (boardHeight - 1)) { return };

    let hexInfo = hexList[position.x][position.y];


    if (hexInfo.hasOwnProperty("playerIdx")) { return };
    if (hexInfo.color == "black") { return };

    let enemyColor = playersList[(1 - activePlayer)].color;
    if (hexInfo.color == enemyColor) { return };

    let hasParentHex = closestHexParent(position, activePlayer);
    if (!hasParentHex) { return };

    playersList[activePlayer].color = hexInfo.color;
    hexInfo.color = null;
    hexInfo.playerIdx = activePlayer;

    updateCanvas();
    updatePlayerDisplayColor();
    switchPlayer();
}

/**
 * Переключение текущего активного игрока<br>
 * Используемые элементы:<br>
 * [Функция] {@link updatePlayerHighlight}<br>
 * [Функция] {@link canPlayerMove}<br>
 * [Функция] {@link gameOver}<br>
 * @param {boolean} isGameOver - Завершение игры, если игрок не может передвигаться
 */
function switchPlayer(isGameOver = false) {
    activePlayer = (activePlayer + 1) % playersList.length;
    updatePlayerHighlight();

    if (canPlayerMove()) { return };

    if (isGameOver) {
        gameOver();
    } else {
        switchPlayer(true);
    }
}

/**
 * Проверка возможности для хода текущего игрока<br>
 * Используемые элементы:<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Переменная списка] {@link hexList}<br>
 * [Функция] {@link closestHexFree}<br>
 * @returns {boolean} - Возможность хода игрока
 */
function canPlayerMove() {
    for (let x = 0; x < boardWidth; x++) {
        for (let y = 0; y < boardHeight; y++) {
            let infoHex = hexList[x][y];
            if (infoHex.hasOwnProperty("playerIdx")) {
                if (infoHex.playerIdx == activePlayer) {
                    if (closestHexFree({x: x, y: y})) { 
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

/**
 * Нахождение соприкасающегося свободного гексагона<br>
 * Используемые элементы:<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Переменная списка] {@link hexList}<br>
 * [Переменная списка] {@link playersList}<br>
 * @param {position} position - Позиция родительского гексагона
 * @param {boolean} [getCoord] - Вернуть положение найденного гексагона
 * @returns {boolean|position} - Найден ближайший гексагон | Позиция гексагона
 */
function closestHexFree(position, getCoord = false) {
    for (let offsetX = -1; offsetX <= 1; offsetX++) {
        for (let offsetY = -1; offsetY <= 1; offsetY++) {
            if (position.y % 2 == 1) {
                if ((offsetX == -1) && (offsetY != 0 )) { continue };
            } else {
                if ((offsetX == 1) && (offsetY != 0 )) { continue };
            }

            let x = Math.max(Math.min((position.x + offsetX), (boardWidth -  1)), 0);
            let y = Math.max(Math.min((position.y + offsetY), (boardHeight - 1)), 0);

            let hexInfo = hexList[x][y];

            if (!hexInfo) { continue };

            if (hexInfo.color == "black") { continue };
            if (hexInfo.hasOwnProperty("playerIdx")) { continue };

            let enemyColor = playersList[(1 - activePlayer)].color;
            if (hexInfo.color == enemyColor) { continue };

            if (getCoord) { return { x: x, y: y } }
            return true;
        }
    }
    return false;
}

/**
 * Нахождение соприкасающегося родительского гексагона игрока<br>
 * Используемые элементы:<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Переменная списка] {@link hexList}<br>
 * @param {position} position - Позиция гексагона
 * @param {number} playerIdx - Номер игрока
 * @returns {boolean} - Найден ближайший гексагон
 */
function closestHexParent(position, playerIdx) {
    for (let offsetX = -1; offsetX <= 1; offsetX++) {
        for (let offsetY = -1; offsetY <= 1; offsetY++) {
            if (position.y % 2 == 1) {
                if ((offsetX == -1) && (offsetY != 0 )) { continue };
            } else {
                if ((offsetX == 1) && (offsetY != 0 )) { continue };
            }

            let x = Math.max(Math.min((position.x + offsetX), (boardWidth  - 1)), 0);
            let y = Math.max(Math.min((position.y + offsetY), (boardHeight - 1)), 0);

            let hexInfo = hexList[x][y];

            if (!hexInfo) { continue };
            if (!hexInfo.hasOwnProperty("playerIdx")) { continue };
            if (hexInfo.playerIdx != playerIdx) { continue };

            return true;
        }
    }
    return false;
}


/* Функции бота */

setInterval(updateBotMovement, 100);

/**
 * Логика движения бота при игре "1vPC"<br>
 * Используемые элементы:<br>
 * [Переменная] {@link isGameStarted}<br>
 * [Переменная] {@link activePlayer}<br>
 * [Переменная] {@link isGameBot}<br>
 * [Переменная] {@link boardWidth}<br>
 * [Переменная] {@link boardHeight}<br>
 * [Переменная списка] {@link hexList}<br>
 * [Функция] {@link closestHexFree}<br>
 * [Функция] {@link setPlayerColorHex}<br>
 */
function updateBotMovement() {
    // return
    if (!isGameStarted) { return };
    if (activePlayer != 1) { return };
    if (!isGameBot) { return };

    for (let x = 0; x < boardWidth; x++) {
        for (let y = 0; y < boardHeight; y++) {
            let infoHex = hexList[x][y];
            if (infoHex.hasOwnProperty("playerIdx")) {
                if (infoHex.playerIdx == activePlayer) {
                    let position = closestHexFree({x: x, y: y}, true);
                    if (position) {
                        setPlayerColorHex(position);
                        return
                    }
                }
            }
        }
    }
}


/* Инициализация игры */

updateScreenSizing();

fillRandomHexBoard();
createHexLineBorder(hexLineBorder);

hexList[0][boardHeight-1].playerIdx = 0;
playersList[0].color = hexList[0][boardHeight-1].color;
hexList[0][boardHeight-1].color = null;

hexList[boardWidth-1][0].playerIdx = 1;
playersList[1].color = hexList[boardWidth-1][0].color
hexList[boardWidth-1][0].color = null;

while (playersList[0].color == playersList[1].color) {
    let colorIdx = getRandomColorIndex();
    playersList[1].color = colorsList[colorIdx];
}


/**
 * Событие при изменении размера экрана
 */
window.addEventListener("resize", updateScreenSizing);

/**
 * Событие при передвижении мыши по холсту
 */
canvas.addEventListener("mousemove", (event) => { 
    if (!isGameStarted) { return };

    mousePosition.x = event.offsetX || event.layerX; 
    mousePosition.y = event.offsetY || event.layerY; 

    hexSelected.x = Math.floor((mousePosition.x - (hexSelected.y % 2) * hexRadius) / hexRectangleWidth);
    hexSelected.y = Math.floor(mousePosition.y / (hexHeight + hexSideLength)); 

    if (hexSelected.x == previousHexSelected.x && hexSelected.y == previousHexSelected.y) { return };
    previousHexSelected = { x: hexSelected.x, y: hexSelected.y };

    let screenPosition = { x: 0, y: 0 };
    screenPosition.x = hexSelected.x * hexRectangleWidth + ((hexSelected.y % 2) * hexRadius); 
    screenPosition.y = hexSelected.y * (hexSideLength + hexHeight); 

    updateCanvas();
    if(hexSelected.x >= 0 && hexSelected.x < boardWidth) { 
        if(hexSelected.y >= 0 && hexSelected.y < boardHeight) {
            drawHexagon(screenPosition.x, screenPosition.y, true, highlightFill); 
        } 
    } 
});

/**
 * Событие при нажатии левой кнопкой мыши по холсту
 */
canvas.addEventListener("click", (event) => {
    if (!isGameStarted) { return };
    if (hexSelected) {
        setPlayerColorHex(hexSelected);
    }
});

/**
 * Событие для кнопки начала игры
 */
play_buttons[0].addEventListener("click", () => {
    isGameBot = true;
    gameStart();
});
play_buttons[1].addEventListener("click", gameStart);