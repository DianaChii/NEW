const path = require('path');

module.exports = {
    entry: "./scripts/hexagons.js",
    output: {
        filename: "compiled.js",
        path: path.resolve(__dirname, "scripts"),
    },
    mode: "production",
};